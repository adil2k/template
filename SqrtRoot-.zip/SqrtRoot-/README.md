# SqrtRoot-
A program that calculates the square root of a given number
